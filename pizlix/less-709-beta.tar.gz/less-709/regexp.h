/*
 * Definitions etc. for regexp(3) routines.
 *
 * Caveat:  this is V8 regexp(3) [actually, a reimplementation thereof],
 * not the System V one.
 */

#ifndef _REGEXP
#define _REGEXP 1

#define NSUBEXP  10
typedef struct regexp {
        constant char *startp[NSUBEXP];
        constant char *endp[NSUBEXP];
        char regstart;          /* Internal use only. */
        char reganch;           /* Internal use only. */
        char *regmust;          /* Internal use only. */
        char program[1];        /* Unwarranted chumminess with compiler. */
} regexp;

#if defined(__STDC__) || defined(__cplusplus)
#   define _ANSI_ARGS_(x)       x
#else
#   define _ANSI_ARGS_(x)       ()
#endif

extern regexp *regcomp _ANSI_ARGS_((constant char *exp));
extern int regexec _ANSI_ARGS_((regexp *prog, constant char *string));
extern int regexec2 _ANSI_ARGS_((regexp *prog, constant char *string, int notbol));
extern void regsub _ANSI_ARGS_((regexp *prog, constant char *source, char *dest));
extern void regerror _ANSI_ARGS_((constant char *msg));

#ifdef DEBUG
  extern void regdump _ANSI_ARGS_((regexp *r));
#endif

#endif /* REGEXP */
