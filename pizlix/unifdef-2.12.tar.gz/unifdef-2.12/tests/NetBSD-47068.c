#ifdef foo
#endif