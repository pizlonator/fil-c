unifdef -DFOO whitespace.c
