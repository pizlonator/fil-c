#define FOO \
        bar
