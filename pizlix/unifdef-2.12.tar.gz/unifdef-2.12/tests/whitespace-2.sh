unifdef -DBAR whitespace.c
